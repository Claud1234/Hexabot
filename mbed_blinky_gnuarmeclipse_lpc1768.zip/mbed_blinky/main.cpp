#include "mbed.h"
#include "decoder.h"
#include "Motor.h"
#include "PID.h"
#include "MotorControl.h"
#include "USBSerial.h"

USBSerial serial;


Serial pc(USBTX, USBRX);
DigitalOut blueLED(P1_18);
DigitalOut redLED(P1_19);
Ticker motorTicker;
Ticker LEDTicker;
MotorControl motor2(P2_0, P4_29, P4_28, P0_7, P0_6);
MotorControl motor3(P2_1, P0_9, P0_8, P2_6, P2_7);
MotorControl motor5(P2_2, P0_15, P0_16, P0_17, P0_18);
MotorControl motor0(P2_3, P0_19, P0_20, P0_21, P0_22);
MotorControl motor1(P2_4, P0_23, P0_24, P0_25, P0_26);
MotorControl motor4(P2_5, P3_25, P3_26, P2_12, P2_13);

char buf[64];
int  SerialCount = 0;

bool shouldSendFeedback = false;


void LEDTick() {
    blueLED = !blueLED;  
    //shouldSendFeedback = true; 
    }

    
void motorTick() {
    motor0.motorTick();
    motor1.motorTick();
    motor2.motorTick();
    motor3.motorTick();
    motor4.motorTick();
    motor5.motorTick();
}

void exractCommand (char *buffer)
    {
        char *cmd = strtok(buffer, ":");
        redLED =!redLED;
        
        if (strncmp(cmd, "ps", 2) == 0)
            {   
                shouldSendFeedback = true; 
                
                motor0.SettingPosition = atoi(strtok(NULL, ":"));
                motor0.MaxSpeedSetting = atoi(strtok(NULL, ":"));
                
                motor1.SettingPosition = atoi(strtok(NULL, ":"));
                motor1.MaxSpeedSetting = atoi(strtok(NULL, ":"));
                
                motor2.SettingPosition = atoi(strtok(NULL, ":"));
                motor2.MaxSpeedSetting = atoi(strtok(NULL, ":"));
                
                motor3.SettingPosition = atoi(strtok(NULL, ":"));
                motor3.MaxSpeedSetting = atoi(strtok(NULL, ":"));
                
                motor4.SettingPosition = atoi(strtok(NULL, ":"));
                motor4.MaxSpeedSetting = atoi(strtok(NULL, ":"));
                
                motor5.SettingPosition = atoi(strtok(NULL, ":"));
                motor5.MaxSpeedSetting = atoi(strtok(NULL, ":"));
                }
    }   


int main() {
    pc.baud(115200);
    motorTicker.attach_us(&motorTick, 10000);
    LEDTicker.attach_us(&LEDTick, 200000);
    while(1) {
        
    if (serial.readable())
    {
        buf[SerialCount] = serial.getc();
        
        
        if (buf[SerialCount] == '\n')
        {
            exractCommand(buf);
            SerialCount = 0;
            memset(buf, 0 , 64);
            }
        else
        {
           ++SerialCount;    
           }          
    }
    
//    if (shouldSendFeedback)
//    {
//        shouldSendFeedback = false;      
//        serial.printf("Pos0:%d, PWM0:%d, Speed0:%d\n", motor0.getPosition(), motor0.getPWM(), motor0.getSpeed());
//        serial.printf("Pos1:%d, PWM1:%d, Speed1:%d\n", motor1.getPosition(), motor1.getPWM(), motor1.getSpeed());
//        serial.printf("Pos2:%d, PWM2:%d, Speed2:%d\n", motor2.getPosition(), motor2.getPWM(), motor2.getSpeed());
//        }
    if (shouldSendFeedback)
    {
        shouldSendFeedback = false;      
        serial.printf("Pos0:%d, Pos1:%d, Pos2:%d, Pos3:%d, Pos4:%d, Pos5:%d\n", motor0.getPosition(), motor1.getPosition(), motor2.getPosition(), motor3.getPosition(), motor4.getPosition(), motor5.getPosition());
        }
}
}
